# Current state — Hyzen

Version 1.2.0+3. Android package: `com.hyzen.pharmd` (unchanged).

This continuation adds download-first native notes preview, multi-format offline
notes with Office-to-PDF export/fallback reading, permanent signing setup, a
verified non-Play-Store in-app updater and the purple reference-led redesign.
Five generated transparent illustrations are integrated. Prior admin, auth,
year filtering and content controls are preserved. See `docs/RELEASE_1_2_SETUP.md`
and `docs/VALIDATION_1_2.md` for current setup and evidence. Historical 1.1.0
reports remain in docs for context only.

No live backend writes or rules deployment were performed. Cross-device profile
sync requires the owner-only student rules to be merged into deployed rules.
Closed-app notifications require FCM setup. No update manifest has been published.
The permanent key and passwords are in a separate PRIVATE owner backup; restore
them before future release builds. Physical phone acceptance and end-to-end
future update delivery require the owner/device checks documented in validation.
