# PHARM D WITH HYZEN — Android study app

Updated Flutter source, version **1.3.3+7 working revision**, continued from the existing 1.2.0 project.
The 1.3.0+4 signed APK and its validation are historical; they do not contain
the current 1.3.3+7 source changes. Flutter/Android build tools are not present
in the current workspace, so this revision has not yet been compiled.
Read `docs/PDF_STUDIO_IMPLEMENTATION_STATUS.md` for current changes and validation boundaries.
PDF Studio now includes a private workspace, Android file import, on-device
reading, basic merge/split/page organization, image-to-PDF, plain text writing
and several export options. The new page operations rasterize original pages.
Precise text anchored annotations, DOCX editing and advanced PDF encryption/compression
remain future work.
The previous 1.2.0 APK does not contain the changes in this working source.
The supplied website HTML and screenshots were used to map backend fields,
admin controls, founder content and brand colours. Start with
`docs/PDF_STUDIO_IMPLEMENTATION_STATUS.md`. The 1.2.0 release and validation reports are
historical records and do not establish acceptance for these new edits.

## Build and run

Validated SDK: Flutter 3.35.4 / Dart 3.9.2, full JDK 17. Android minimum API 24.
Install Android SDK platforms 34/35/36, build tools 35.0.0, NDK 27.0.12077973
and CMake 3.22.1. Android build configuration uses Gradle 8.13, AGP 8.13.2
and Kotlin 2.3.0 to match the pinned native plugins. Keep the pinned dependencies in `pubspec.lock`.

```sh
flutter pub get
flutter analyze --no-pub
flutter test --no-pub
flutter build apk --release
```

Release output: `build/app/outputs/flutter-apk/app-release.apk`.
This release uses the **permanent production signing identity**. Restore
`android/signing/hyzen-release.jks` and `android/key.properties` from the separate
private owner signing backup before building a release. Never replace this key
for future updates. The old 1.1.0 development-signed build has a different
signature: back up important local data before the one-time transition.

## Student experience

- Android Back pops the current page, returns other tabs to Home and asks
  before closing from Home. A notification dialog dismisses with Back.
- Reference-led purple/lavender light and dark themes, rounded opaque cards,
  consistent Manrope typography, native controls and five generated illustrations.
- Personal welcome, study shortcuts, subject discovery and recent reading.
- Signup has expanded Pakistan city/town options and manual city entry.
  Keyboard focus survives typing, resize and form scrolling.
- Durable account-scoped profile cache, immediate local editing and background
  sync. Completed profiles are retained after successful sync/relaunch.
- Professional-year filtering for library, lectures and search. Students can
  change their year through Profile or Settings. Admin can view all years.
- Optional profile photo: Android photo picker, bounded/resized image,
  Cloudinary upload and saved profile URL.
- Drive/Docs embedded previews, direct PDF viewer, loading progress, retry and
  browser fallback. Public PDF downloads include progress, rate/ETA when
  available, cancel, duplicate protection, validation and offline reading.
  Saved PDFs can be exported to a chosen device folder.
- Header notification bell, unread badge and an account-scoped inbox for live
  announcements/full-screen notices. Founder photos use the website credit
  card's `photo` field.

## Admin controls

The configured website administrator can access grouped dashboard cards and
an admin navigation drawer. Routes are guarded; Firestore rules remain the
final authority. The app does not let a student grant themselves admin access.

Dashboard/statistics; Notes; Special Books & Notes; Lectures; MCQs; Past Papers;
Bulk Import/history; Data Manager; Products; Orders; Catalog; Delivery;
Messages; Theme studio; Announcement; Full-screen notifications; About/team/
social; Blog posts; section visibility; Settings; backend connection check;
student view and logout are included.

Content supports add/edit/delete, hierarchy, ordering and publication. Store
controls include product media/variants/stock, category management, delivery
rates, atomic order/message inbox processing, order tracking/status, CSV and
printable HTML invoice export. Messages offer explicit email/WhatsApp reply
links. No messages are sent automatically.

Website theme/announcement presentation controls are preserved in their
original backend fields. Native navigation remains opaque and inexpensive;
website ring/glitter and marquee settings are website presentation settings.
The default native palette and per-palette logos are used by the app.

## Bulk import and backups

Choose CSV, JSON row arrays or XLSX through the system picker. Limits: 20 files,
4 MB per file, 2,000 rows. Legacy `.xls` files must be converted to CSV/XLSX.
The template is `docs/hyzen_bulk_import_template.csv`.

Columns: `kind,professional_year,semester,subject,section,topic,title,url,published`.
Kinds: `notes`, `mcqs`, `special`, `papers`, `lectures`. Website header aliases
are accepted. Review validated rows and duplicates before committing. Imports
merge with fresh server trees. Data Manager handles JSON content backup/restore
with format and document-size validation plus destructive-action confirmation.

## Backend setup and remaining acceptance checks

The existing Firebase project, admin UID and Cloudinary unsigned upload preset
are retained. No production rules or admin data were changed in this revision.
Read `docs/STUDENT_PROFILE_RULES.md` and merge its owner-only profile block into
the actual deployed rules. `firestore.rules.proposed` is a reference proposal,
not a replacement for rules you have not inspected.

Cross-device profile sync depends on those live profile rules. In-app notices
update while the app runs; closed-app push needs separate FCM setup. Private,
deleted or quota-limited Drive files cannot be made public by a preview fix.
Native WebView, Android file/photo picker, offline PDF and performance need a
physical-phone acceptance check. Release APK compilation is not a phone-speed
benchmark. Final store signing and owner Terms/Privacy remain release work.
