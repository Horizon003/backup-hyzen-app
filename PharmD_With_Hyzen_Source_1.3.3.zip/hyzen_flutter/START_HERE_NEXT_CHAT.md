# Continue PHARM D WITH HYZEN 1.3.3+7 source

The latest implementation and exact gaps are in `docs/PDF_STUDIO_IMPLEMENTATION_STATUS.md`.
Read that file and `README.md` first. The source includes a new HD capsule logo,
native Android PDF tools, non-destructive in-app annotations, and export flows.
The signed **1.3.3+7 APK has now been built successfully** through the private
GitHub repository `Horizon003/pharm-d-with-hyzen`, run `38841171153`.
Flutter 3.35.4 / Dart 3.9.2 and JDK 17 are pinned for the build.
Analysis has zero issues and all 62 automated tests pass.
The APK certificate matches the original key and old 1.3.0 APK.
Read `docs/VALIDATION_1_3_3.md` for Android install verification and limitations.

The private release keystore and `android/key.properties` are omitted from the
source archive. In the current active workspace they reside in the local
project's `android/signing/` and `android/` directories. Preserve the existing
signing identity; a newly generated key cannot update existing installations.

The original 1.2.0 and 1.3.0 validation reports are historical records.
For future updates use the same private GitHub Actions signing secrets and
increase the build number in `pubspec.yaml`. The source archive omits all
signing credentials. Real-phone acceptance must still check imported files,
Drive preview, offline reading, every PDF Studio operation and both themes
with real documents. Do not describe advanced features still listed as missing
in the implementation status as complete.
