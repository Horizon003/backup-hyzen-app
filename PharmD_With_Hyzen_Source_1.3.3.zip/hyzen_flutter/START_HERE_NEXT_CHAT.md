# Continue PHARM D WITH HYZEN 1.3.3+7 source

The latest implementation and exact gaps are in `docs/PDF_STUDIO_IMPLEMENTATION_STATUS.md`.
Read that file and `README.md` first. The source includes a new HD capsule logo,
native Android PDF tools, non-destructive in-app annotations, and export flows.
It has **not** been compiled or device-tested in this workspace: the Flutter
SDK is absent and Gradle 8.13 could not download. Do not present an older
1.3.0 APK as this version. Build the 1.3.3+7 source with the original owner
release signing files, then run device acceptance tests before distribution.

The private release keystore and `android/key.properties` are omitted from the
source archive. In the current active workspace they reside in the local
project's `android/signing/` and `android/` directories. Preserve the existing
signing identity; a newly generated key cannot update existing installations.

The original 1.2.0 and 1.3.0 validation reports are historical records.
Before any release, run `flutter pub get`, `flutter analyze`, `flutter test`,
`flutter build apk --release`, verify the original signing certificate and
install the APK on a phone. Check imported files, offline reading, every PDF
Studio operation and both theme modes with real documents.
