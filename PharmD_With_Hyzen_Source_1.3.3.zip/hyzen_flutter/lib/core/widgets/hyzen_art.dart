import 'package:flutter/material.dart';
import '../theme/tokens.dart';

class HyzenArt extends StatelessWidget {
  const HyzenArt(this.name, {super.key, this.size = 160});
  final String name;
  final double size;
  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/illustrations/$name.png',
    width: size,
    height: size,
    fit: BoxFit.contain,
    cacheWidth: (size * 2).round(),
    excludeFromSemantics: true,
  );
}

class HyzenBanner extends StatelessWidget {
  const HyzenBanner({
    super.key,
    required this.title,
    required this.subtitle,
    required this.art,
    this.eyebrow,
    this.action,
    this.actionLabel,
  });
  final String title, subtitle, art;
  final String? eyebrow, actionLabel;
  final VoidCallback? action;
  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final dark = t.brightness == Brightness.dark;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: dark
              ? const [Color(0xFF2D2245), Color(0xFF36234F)]
              : const [Color(0xFFF5EFFF), Color(0xFFEFE6FF)],
        ),
      ),
      child: LayoutBuilder(
        builder: (context, c) {
          final narrow =
              c.maxWidth < 330 ||
              MediaQuery.textScalerOf(context).scale(1) > 1.25;
          final text = Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 8, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (eyebrow != null) ...[
                  Text(
                    eyebrow!.toUpperCase(),
                    style: t.textTheme.labelSmall?.copyWith(
                      color: dark
                          ? const Color(0xFFC8AAFF)
                          : HColors.primaryDeep,
                      letterSpacing: .8,
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                Text(
                  title,
                  style: t.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  subtitle,
                  style: t.textTheme.bodyMedium?.copyWith(
                    height: 1.4,
                    fontSize: action != null ? 12 : 13,
                  ),
                ),
                if (action != null) ...[
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: action,
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(0, 42),
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: Text(
                            actionLabel ?? 'Explore',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Icon(Icons.arrow_forward_rounded, size: 18),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          );
          return Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(flex: narrow ? 7 : 6, child: text),
              Expanded(
                flex: narrow ? 4 : 5,
                child: HyzenArt(art, size: c.maxWidth * .52),
              ),
            ],
          );
        },
      ),
    );
  }
}
