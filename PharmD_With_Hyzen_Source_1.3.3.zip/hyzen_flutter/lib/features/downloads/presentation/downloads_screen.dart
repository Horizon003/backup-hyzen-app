import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/tokens.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/ui_kit.dart';
import '../../academics/domain/models.dart';
import '../../academics/presentation/library_screens.dart';
import '../../shell/app_shell.dart';
import '../data/downloads_controller.dart';
import '../domain/download_record.dart';
import '../../viewer/external_files.dart';
import '../../../core/widgets/hyzen_art.dart';

enum _Sort { newest, name, size }

class DownloadsScreen extends ConsumerStatefulWidget {
  const DownloadsScreen({super.key});
  @override
  ConsumerState<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends ConsumerState<DownloadsScreen> {
  LibraryKind? _kind;
  String _q = '';
  _Sort _sort = _Sort.newest;

  @override
  Widget build(BuildContext context) {
    final all = ref.watch(downloadsProvider).values.toList();
    final opened = ref
        .watch(externalHistoryProvider)
        .where(
          (item) =>
              _q.isEmpty || item.title.toLowerCase().contains(_q.toLowerCase()),
        )
        .toList();
    final used = all.where((r) => r.isReady).fold(0, (s, r) => s + r.sizeBytes);
    var list = all
        .where(
          (r) =>
              (_kind == null || r.kind == _kind) &&
              (_q.isEmpty ||
                  '${r.title} ${r.subtitle}'.toLowerCase().contains(
                    _q.toLowerCase(),
                  )),
        )
        .toList();
    list.sort(
      (a, b) => switch (_sort) {
        _Sort.newest => (b.savedAt ?? DateTime(2100)).compareTo(
          a.savedAt ?? DateTime(2100),
        ),
        _Sort.name => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
        _Sort.size => b.sizeBytes.compareTo(a.sizeBytes),
      },
    );
    final t = Theme.of(context);
    return TabPage(
      title: 'Downloads',
      subtitle: 'Read anywhere, even offline',
      actions: [
        PopupMenuButton<_Sort>(
          tooltip: 'Sort',
          icon: const Icon(Icons.sort_rounded),
          initialValue: _sort,
          onSelected: (s) => setState(() => _sort = s),
          itemBuilder: (_) => const [
            PopupMenuItem(value: _Sort.newest, child: Text('Newest first')),
            PopupMenuItem(value: _Sort.name, child: Text('Name A\u2013Z')),
            PopupMenuItem(value: _Sort.size, child: Text('Largest first')),
          ],
        ),
      ],
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: HSpace.screen),
          sliver: SliverList.list(
            children: [
              HeroPanel(
                eyebrow: 'Offline library',
                title: '${all.where((r) => r.isReady).length} saved files',
                subtitle: kIsWeb
                    ? 'Save Offline is available in the Android app.'
                    : 'Stored privately on this device.',
                icon: Icons.download_done_rounded,
                stats: [(formatBytes(used), 'used')],
              ),
              const Gap(HSpace.md),
              HSearchField(
                hint: 'Search downloads',
                onChanged: (v) => setState(() => _q = v),
              ),
              const Gap(HSpace.sm),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final k in [null, ...LibraryKind.values])
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(k == null ? 'All' : k.shortTitle),
                          selected: _kind == k,
                          onSelected: (_) => setState(() => _kind = k),
                        ),
                      ),
                  ],
                ),
              ),
              const Gap(HSpace.md),
              if (list.isEmpty && all.isEmpty)
                const Center(child: HyzenArt('downloads', size: 160)),
              if (list.isEmpty)
                EmptyState(
                  icon: Icons.cloud_download_outlined,
                  title: all.isEmpty ? 'No downloads yet' : 'No matches',
                  message: all.isEmpty
                      ? 'Open any file and tap \u201cSave offline\u201d.'
                      : null,
                  action: all.isEmpty
                      ? HButton(
                          label: 'Browse library',
                          onPressed: () => context.go('/study'),
                        )
                      : null,
                ),
              for (final r in list) _DownloadRow(r: r),
              if (opened.isNotEmpty) ...[
                const Gap(HSpace.lg),
                Text('Opened with PHARM D WITH HYZEN', style: t.textTheme.titleMedium),
                Text(
                  'Files from WhatsApp or your phone stay here for offline reading.',
                  style: t.textTheme.bodySmall,
                ),
                const Gap(HSpace.sm),
                for (final item in opened)
                  ResourceTile(
                    icon: Icons.picture_as_pdf_outlined,
                    color: t.colorScheme.primary,
                    title: item.title,
                    subtitle:
                        'Opened ${item.openedAt.toLocal().toString().split('.').first}',
                    onTap: () {
                      final updated = ExternalDocument(
                        item.id,
                        item.title,
                        item.path,
                        DateTime.now(),
                      );
                      ref.read(externalHistoryProvider.notifier).add(updated);
                      context.push('/imported-viewer', extra: updated);
                    },
                    trailing: IconButton(
                      tooltip: 'Delete imported file',
                      icon: const Icon(Icons.delete_outline_rounded),
                      onPressed: () async {
                        if (await confirmDialog(
                          context,
                          title: 'Delete this file?',
                          message:
                              'This removes PHARM D WITH HYZEN’s local copy of “${item.title}”.',
                          confirm: 'Delete',
                          destructive: true,
                        )) {
                          await ref
                              .read(externalHistoryProvider.notifier)
                              .delete(item);
                        }
                      },
                    ),
                  ),
              ],
              if (all.isNotEmpty) ...[
                const Gap(HSpace.md),
                TextButton.icon(
                  style: TextButton.styleFrom(foregroundColor: HColors.error),
                  onPressed: () async {
                    if (await confirmDialog(
                      context,
                      title: 'Delete all downloads?',
                      message:
                          'Local copies are removed from this phone. Original files are not affected.',
                      confirm: 'Delete all',
                      destructive: true,
                    )) {
                      await ref.read(downloadsProvider.notifier).removeAll();
                    }
                  },
                  icon: const Icon(Icons.delete_sweep_rounded),
                  label: Text(
                    'Delete all local copies',
                    style: t.textTheme.labelLarge?.copyWith(
                      color: HColors.error,
                    ),
                  ),
                ),
              ],
              if (opened.isNotEmpty)
                TextButton.icon(
                  onPressed: () async {
                    if (await confirmDialog(
                      context,
                      title: 'Clear reader history?',
                      message:
                          'Imported local files will be removed from PHARM D WITH HYZEN.',
                      confirm: 'Clear history',
                      destructive: true,
                    )) {
                      for (final item in List<ExternalDocument>.from(
                        ref.read(externalHistoryProvider),
                      )) {
                        await ref
                            .read(externalHistoryProvider.notifier)
                            .delete(item);
                      }
                    }
                  },
                  icon: const Icon(Icons.history_rounded),
                  label: const Text('Clear reader history'),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _DownloadRow extends ConsumerWidget {
  const _DownloadRow({required this.r});
  final DownloadRecord r;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = switch (r.status) {
      DownloadStatus.ready => StatusPill(
        label: 'Offline \u00b7 ${formatBytes(r.sizeBytes)}',
        color: HColors.success,
        icon: Icons.check_circle_rounded,
      ),
      DownloadStatus.downloading => StatusPill(
        label: r.progress > 0
            ? 'Downloading ${(r.progress * 100).round()}%'
            : 'Downloading\u2026',
        color: HColors.info,
        icon: Icons.downloading_rounded,
      ),
      DownloadStatus.failed => const StatusPill(
        label: 'Failed \u00b7 tap to retry',
        color: HColors.error,
        icon: Icons.error_rounded,
      ),
    };
    final file = FileRef(
      kind: r.kind,
      title: r.title,
      url: r.sourceUrl,
      trail: r.trail,
    );
    return ResourceTile(
      icon: kindIcon(r.kind),
      color: kindColor(r.kind),
      eyebrow: r.kind.shortTitle,
      title: r.title,
      subtitle: r.subtitle,
      badge: status,
      onTap: () => context.push('/viewer', extra: file),
      trailing: IconButton(
        tooltip: 'Delete local copy',
        icon: const Icon(Icons.delete_outline_rounded),
        onPressed: () async {
          if (await confirmDialog(
            context,
            title: 'Delete local copy?',
            message:
                '\u201c${r.title}\u201d will be removed from this phone only.',
            confirm: 'Delete',
            destructive: true,
          )) {
            await ref.read(downloadsProvider.notifier).remove(r.key);
            if (context.mounted) showHSnack(context, 'Local copy deleted');
          }
        },
      ),
    );
  }
}
