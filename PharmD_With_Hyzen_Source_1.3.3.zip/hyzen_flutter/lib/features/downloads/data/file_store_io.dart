import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import '../../viewer/office_document.dart';

import '../../../core/errors/app_error.dart';
import '../domain/download_record.dart';
import '../domain/drive_confirmation.dart';
import 'file_store.dart';
import '../domain/document_type.dart';
import '../../academics/domain/drive.dart';

FileStore createFileStore({
  Directory? testDirectory,
  http.Client Function()? clientFactory,
}) => _IoFileStore(testDirectory, clientFactory);

class _IoFileStore implements FileStore {
  _IoFileStore(this.testDirectory, this.clientFactory);
  final Directory? testDirectory;
  final http.Client Function()? clientFactory;
  @override
  bool get supported => true;

  Future<Directory> _dir() async {
    final base = testDirectory ?? await getApplicationSupportDirectory();
    final d = Directory('${base.path}/offline_docs');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  String _safe(String key) => key.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');

  @override
  Future<DownloadedFile> download(
    String url,
    String key,
    ProgressCb onProgress, {
    bool Function()? cancelled,
  }) async {
    try {
      return await _downloadOnce(url, key, onProgress, cancelled: cancelled);
    } on FriendlyException {
      final id = DriveLinks.fileId(url);
      if (Uri.tryParse(url)?.host != 'docs.google.com' ||
          id.isEmpty ||
          cancelled?.call() == true) {
        rethrow;
      }
      return _downloadOnce(
        DriveLinks.downloadUrl(
          Uri.https(
            'drive.google.com',
            '/file/d/$id/view',
            Uri.parse(url).queryParameters['resourcekey'] == null
                ? null
                : {
                    'resourcekey': Uri.parse(
                      url,
                    ).queryParameters['resourcekey']!,
                  },
          ).toString(),
        ),
        key,
        onProgress,
        cancelled: cancelled,
      );
    }
  }

  Future<DownloadedFile> _downloadOnce(
    String url,
    String key,
    ProgressCb onProgress, {
    bool Function()? cancelled,
  }) async {
    final dir = await _dir();
    var finalFile = File('${dir.path}/${_safe(key)}.pdf');
    final part = File('${finalFile.path}.part');
    if (await part.exists()) await part.delete();
    final client = clientFactory?.call() ?? http.Client();
    IOSink? sink;
    final cancelTimer = Timer.periodic(const Duration(milliseconds: 150), (_) {
      if (cancelled?.call() == true) client.close();
    });
    try {
      if (cancelled?.call() == true) {
        throw FriendlyException('Download cancelled.');
      }
      final req = http.Request('GET', Uri.parse(url))..followRedirects = true;
      var res = await client.send(req).timeout(const Duration(seconds: 30));
      if ((res.headers['content-type'] ?? '').contains('text/html')) {
        final html = await res.stream.take(256).fold<List<int>>([], (
          all,
          chunk,
        ) {
          if (all.length + chunk.length > 1024 * 1024) {
            throw FriendlyException('Drive returned an unavailable file page.');
          }
          return all..addAll(chunk);
        });
        final confirm = driveConfirmation(
          String.fromCharCodes(html),
          Uri.parse(url),
        );
        if (confirm != null) {
          res = await client
              .send(http.Request('GET', confirm))
              .timeout(const Duration(seconds: 30));
        } else {
          throw FriendlyException(
            'This Drive file is private or its download quota has been reached. Open the original link or try again later.',
          );
        }
      }
      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw FriendlyException(
          res.statusCode == 404
              ? 'This file is no longer available.'
              : 'Download failed (server said ${res.statusCode}). Please retry.',
        );
      }
      final ctype = (res.headers['content-type'] ?? '').toLowerCase();
      if (ctype.contains('text/html')) {
        throw FriendlyException(
          'This file is not shared publicly or Google asked for sign-in, so it can\u2019t be saved offline.',
        );
      }
      final total = res.contentLength;
      const maxBytes = 250 * 1024 * 1024;
      if (total != null && total > maxBytes) {
        throw FriendlyException(
          'This file is too large. Save a PDF smaller than 250 MB.',
        );
      }
      sink = part.openWrite();
      var received = 0;
      final head = <int>[];
      await for (final chunk in res.stream.timeout(
        const Duration(seconds: 45),
      )) {
        if (cancelled?.call() == true) {
          throw FriendlyException('Download cancelled.');
        }
        if (head.length < 1024) head.addAll(chunk.take(1024 - head.length));
        if (head.length >= 16 && documentExtension(head) == null) {
          throw FriendlyException(
            PdfSniffer.looksLikeHtml(head)
                ? 'Google returned a web page instead of the PDF. The file may be private or over the download limit.'
                : 'Use PDF, PPTX, DOCX, XLSX, PNG or JPEG notes.',
          );
        }
        if (received + chunk.length > maxBytes) {
          throw FriendlyException(
            'This file is too large. Save a PDF smaller than 250 MB.',
          );
        }
        sink.add(chunk);
        received += chunk.length;
        onProgress(received, total);
      }
      await sink.flush();
      await sink.close();
      sink = null;
      final extension = documentExtension(head);
      if (extension == null) {
        throw FriendlyException('Downloaded data was not a valid PDF.');
      }
      finalFile = File('${dir.path}/${_safe(key)}.$extension');
      if (extension == 'office' || extension == 'legacy') {
        if (received > 50 * 1024 * 1024) {
          throw FriendlyException(
            'Office notes must be smaller than 50 MB. Ask for a PDF copy.',
          );
        }
        try {
          await compute(officePages, await part.readAsBytes());
        } catch (_) {
          throw FriendlyException(
            'This is not a readable PPTX, DOCX or XLSX file. Ask for a PDF copy.',
          );
        }
      }
      if (total != null && total > 0 && received < total) {
        throw FriendlyException('Download was incomplete. Please retry.');
      }
      if (cancelled?.call() == true) {
        throw FriendlyException('Download cancelled.');
      }
      if (await finalFile.exists()) await finalFile.delete();
      await part.rename(finalFile.path); // atomic finalize
      return DownloadedFile(finalFile.path, received);
    } on FriendlyException {
      rethrow;
    } on TimeoutException {
      throw FriendlyException(
        'The download timed out. Check your connection and retry.',
      );
    } on SocketException {
      throw FriendlyException('No internet connection. Connect and retry.');
    } catch (_) {
      throw FriendlyException('Download failed. Please retry.');
    } finally {
      try {
        await sink?.close();
      } catch (_) {}
      cancelTimer.cancel();
      client.close();
      if (await part.exists()) {
        try {
          await part.delete();
        } catch (_) {}
      }
    }
  }

  @override
  Future<bool> exists(String path) => File(path).exists();

  @override
  Future<DownloadedFile> importPreview(String path, String key) async {
    final directory = await _dir();
    final source = File(path);
    final sourcePath = await source.resolveSymbolicLinks();
    final directoryPath = await directory.resolveSymbolicLinks();
    if (!sourcePath.startsWith('$directoryPath/preview_') ||
        !await source.exists()) {
      throw FriendlyException(
        'Preview is no longer available. Try Save again.',
      );
    }
    final ext = source.path.split('.').last;
    if (!{'pdf', 'jpg', 'png', 'webp', 'office', 'legacy'}.contains(ext)) {
      throw FriendlyException('This note cannot be saved offline.');
    }
    final target = File('${directory.path}/${_safe(key)}.$ext');
    final partial = File('${target.path}.part');
    try {
      await source.copy(partial.path);
      final length = await partial.length();
      if (length <= 0 || length > 250 * 1024 * 1024) {
        throw FriendlyException('This note cannot be saved offline.');
      }
      if (await target.exists()) await target.delete();
      await partial.rename(target.path);
      return DownloadedFile(target.path, length);
    } finally {
      if (await partial.exists()) await partial.delete();
    }
  }

  @override
  Future<void> delete(String path) async {
    final f = File(path);
    if (await f.exists()) await f.delete();
  }

  @override
  Future<void> clearAll() async {
    final d = await _dir();
    if (await d.exists()) await d.delete(recursive: true);
  }
}
