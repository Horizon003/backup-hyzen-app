import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/providers.dart';
import '../../core/theme/tokens.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/ui_kit.dart';
import '../content/data/content_source.dart';
import '../profile/presentation/profile_screens.dart';
import '../shell/app_shell.dart';
import 'data/admin_repository.dart';

const adminGroups = <String, List<(String, IconData, String)>>{
  'Overview': [('Statistics', Icons.insights_rounded, 'stats')],
  'Content': [
    ('Notes', Icons.menu_book_outlined, 'content/notes'),
    ('Special Books & Notes', Icons.auto_stories_outlined, 'content/special'),
    ('Lectures', Icons.play_circle_outlined, 'manage/lectures'),
    ('MCQs', Icons.quiz_outlined, 'content/mcqs'),
    ('Past Papers', Icons.history_edu_outlined, 'content/papers'),
    ('Bulk Import', Icons.upload_file_rounded, 'import'),
    ('Data Manager', Icons.storage_rounded, 'manage/data'),
  ],
  'Store': [
    ('Products', Icons.inventory_2_outlined, 'manage/products'),
    ('Orders', Icons.receipt_long_outlined, 'manage/orders'),
    ('Catalog', Icons.grid_view_rounded, 'manage/catalog'),
    ('Delivery', Icons.local_shipping_outlined, 'manage/delivery'),
  ],
  'Inbox': [('Messages', Icons.forum_outlined, 'manage/messages')],
  'Platform': [
    ('Theme studio', Icons.palette_outlined, 'manage/theme'),
    ('Announcement', Icons.campaign_outlined, 'manage/announcement'),
    (
      'Full-screen notifications',
      Icons.notifications_active_outlined,
      'manage/notice',
    ),
    ('About & Blog', Icons.people_outline_rounded, 'manage/about'),
    ('Blog posts', Icons.article_outlined, 'manage/blogs'),
    ('Section visibility', Icons.toggle_on_outlined, 'sections'),
    ('Settings', Icons.tune_rounded, 'manage/settings'),
  ],
  'Backend': [('Connection', Icons.cloud_outlined, 'manage/connection')],
};

class AdminScreen extends ConsumerStatefulWidget {
  const AdminScreen({super.key});
  @override
  ConsumerState<AdminScreen> createState() => _AdminState();
}

class _AdminState extends ConsumerState<AdminScreen> {
  bool busy = false;
  Future<void> sync() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final count = await ref.read(adminRepositoryProvider).syncInboxes();
      if (mounted) {
        showHSnack(context, 'Inbox refreshed · $count items processed');
      }
      ref.invalidate(contentProvider('pw_products'));
    } catch (_) {
      if (mounted) {
        showHSnack(
          context,
          'Could not refresh inbox. Check your connection and admin permissions.',
          error: true,
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!ref.watch(isAdminProvider)) {
      return const Scaffold(
        body: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: 'Administrator access required',
        ),
      );
    }
    final orders = asMapList(
          ref.watch(adminValueProvider('pw_orders')).valueOrNull,
        ),
        messages = asMapList(
          ref.watch(adminValueProvider('pw_messages')).valueOrNull,
        );
    return TabPage(
      title: 'PHARM D Admin',
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              const Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    HyzenLogo(size: 52, glow: false),
                    Gap(12),
                    Text(
                      'PHARM D WITH HYZEN',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    Text('Admin control centre'),
                  ],
                ),
              ),
              ListTile(
                leading: const Icon(Icons.dashboard_outlined),
                title: const Text('Dashboard'),
                selected: true,
                onTap: () => Navigator.of(context).pop(),
              ),
              for (final group in adminGroups.entries) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
                  child: Text(
                    group.key.toUpperCase(),
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ),
                for (final item in group.value)
                  ListTile(
                    leading: Icon(item.$2),
                    title: Text(item.$1),
                    onTap: () {
                      Navigator.of(context).pop();
                      context.push(
                        item.$3 == 'stats'
                            ? '/admin/stats'
                            : '/admin/${item.$3}',
                      );
                    },
                  ),
              ],
              const Divider(),
              ListTile(
                leading: const Icon(Icons.phone_android_rounded),
                title: const Text('Student view'),
                onTap: () {
                  Navigator.of(context).pop();
                  context.go('/home');
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout_rounded),
                title: const Text('Log out'),
                onTap: () {
                  Navigator.of(context).pop();
                  logout(context, ref);
                },
              ),
            ],
          ),
        ),
      ),
      subtitle: 'PHARM D WITH HYZEN · Admin console',
      actions: [
        IconButton(
          tooltip: 'Student view',
          onPressed: () => context.go('/home'),
          icon: const Icon(Icons.phone_android_rounded),
        ),
      ],
      onRefresh: sync,
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverList.list(
            children: [
              HeroPanel(
                eyebrow: 'Your control centre',
                title: 'Build a better study day.',
                subtitle: 'Content, students and your store — in one place.',
                icon: Icons.admin_panel_settings_rounded,
                stats: [
                  ('${orders.length}', 'orders'),
                  (
                    '${messages.where((m) => m['read'] != true).length}',
                    'unread messages',
                  ),
                ],
              ),
              const Gap(16),
              HButton(
                label: 'Refresh website inbox',
                icon: Icons.sync_rounded,
                loading: busy,
                onPressed: sync,
              ),
              for (final group in adminGroups.entries) ...[
                Padding(
                  padding: const EdgeInsets.only(top: 26, bottom: 12),
                  child: Text(
                    group.key.toUpperCase(),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      letterSpacing: 1.5,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                for (final item in group.value)
                  ResourceTile(
                    icon: item.$2,
                    color: group.key == 'Store'
                        ? HColors.special
                        : HColors.primary,
                    title: item.$1,
                    onTap: () => context.push(
                      item.$3 == 'stats' ? '/admin/stats' : '/admin/${item.$3}',
                    ),
                  ),
              ],
              const Gap(16),
              HButton(
                label: 'Log out',
                outlined: true,
                icon: Icons.logout_rounded,
                onPressed: () => logout(context, ref),
              ),
              const Gap(20),
            ],
          ),
        ),
      ],
    );
  }
}
