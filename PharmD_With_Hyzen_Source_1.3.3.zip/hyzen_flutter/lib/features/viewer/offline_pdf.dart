import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:flutter/foundation.dart';
import 'document_bytes.dart';
import 'office_document.dart';

/// On-device PDF renderer for saved files (works with no network).
/// Includes a built-in text search so externally opened and saved PDFs share
/// the same basic reading tools.
class OfflinePdf extends StatefulWidget {
  const OfflinePdf({super.key, required this.path});
  final String path;

  @override
  State<OfflinePdf> createState() => _OfflinePdfState();
}

class _OfflinePdfState extends State<OfflinePdf> {
  final _controller = PdfViewerController();
  PdfTextSearcher? _searcher;
  PdfTextSearcher get searcher {
    final existing = _searcher;
    if (existing != null) return existing;
    final created = PdfTextSearcher(_controller);
    created.addListener(_onSearch);
    return _searcher = created;
  }
  final _searchText = TextEditingController();
  Timer? _searchDebounce;
  bool _searchOpen = false;

  void _onSearch() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _searcher?.removeListener(_onSearch);
    _searcher?.dispose();
    _searchDebounce?.cancel();
    _searchText.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final path = widget.path;
    if (path.endsWith('.office') || path.endsWith('.legacy') ||
        path.endsWith('.docx') || path.endsWith('.pptx') ||
        path.endsWith('.xlsx') || path.endsWith('.ppt')) {
      return OfficeReader(path: path);
    }
    if (path.endsWith('.txt') || path.endsWith('.md') || path.endsWith('.rtf')) {
      return FutureBuilder(
        future: documentBytes(path),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('Could not read this document.'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final text = utf8.decode(snapshot.data!, allowMalformed: true);
          return SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: SelectableText(text.isEmpty ? 'This document is empty.' : text),
          );
        },
      );
    }
    if (path.endsWith('.jpg') ||
        path.endsWith('.png') ||
        path.endsWith('.webp')) {
      return FutureBuilder(
        future: documentBytes(path),
        builder: (context, s) => s.hasData
            ? InteractiveViewer(
                child: Center(
                  child: Image.memory(
                    s.data!,
                    errorBuilder: (_, __, ___) => const Text(
                      'This saved image is damaged. Delete it and save again.',
                    ),
                  ),
                ),
              )
            : Center(
                child: Text(
                  s.hasError ? 'Image could not open.' : 'Opening image…',
                ),
              ),
      );
    }
    final theme = Theme.of(context);
    return Column(
      children: [
        Material(
          color: theme.colorScheme.surface,
          child: Row(
            children: [
              if (_searchOpen)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 14),
                    child: TextField(
                      controller: _searchText,
                      autofocus: true,
                      textInputAction: TextInputAction.search,
                      decoration: const InputDecoration(
                        hintText: 'Find text in this PDF',
                        border: InputBorder.none,
                        isDense: true,
                      ),
                      onSubmitted: (query) {
                        _searchDebounce?.cancel();
                        if (query.trim().isNotEmpty) {
                          searcher.startTextSearch(query.trim());
                        }
                      },
                      onChanged: (query) {
                        _searchDebounce?.cancel();
                        if (query.trim().isEmpty) {
                          searcher.resetTextSearch();
                        } else {
                          _searchDebounce = Timer(
                            const Duration(milliseconds: 320),
                            () => searcher.startTextSearch(query.trim()),
                          );
                        }
                      },
                    ),
                  ),
                )
              else
                const Spacer(),
              if (_searchOpen && searcher.matches.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text(
                    '${(searcher.currentIndex ?? 0) + 1}/${searcher.matches.length}',
                    style: theme.textTheme.labelSmall,
                  ),
                ),
              if (_searchOpen && searcher.isSearching)
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8),
                  child: SizedBox.square(
                    dimension: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              if (_searchOpen)
                IconButton(
                  tooltip: 'Previous match',
                  onPressed: searcher.matches.isEmpty
                      ? null
                      : () => searcher.goToPrevMatch(),
                  icon: const Icon(Icons.keyboard_arrow_up_rounded),
                ),
              if (_searchOpen)
                IconButton(
                  tooltip: 'Next match',
                  onPressed: searcher.matches.isEmpty
                      ? null
                      : () => searcher.goToNextMatch(),
                  icon: const Icon(Icons.keyboard_arrow_down_rounded),
                ),
              IconButton(
                tooltip: _searchOpen ? 'Close search' : 'Search PDF',
                onPressed: () => setState(() {
                  _searchOpen = !_searchOpen;
                  if (!_searchOpen) {
                    _searchText.clear();
                    searcher.resetTextSearch();
                  }
                }),
                icon: Icon(_searchOpen ? Icons.close_rounded : Icons.search_rounded),
              ),
            ],
          ),
        ),
        Expanded(
          child: PdfViewer.file(
            path,
            controller: _controller,
            params: PdfViewerParams(
              pagePaintCallbacks: [searcher.pageTextMatchPaintCallback],
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
              errorBannerBuilder: (c, e, st, ref) => const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'This saved file can\u2019t be opened. Delete it from Downloads and save it again.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class OfficeReader extends StatefulWidget {
  const OfficeReader({super.key, required this.path});
  final String path;
  @override
  State<OfficeReader> createState() => _OfficeReaderState();
}

class _OfficeReaderState extends State<OfficeReader> {
  late final pages = documentBytes(
    widget.path,
  ).then((b) => compute(officePages, b));
  @override
  Widget build(BuildContext context) => FutureBuilder<List<String>>(
    future: pages,
    builder: (context, s) {
      if (s.hasError) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Could not read these Office notes. ${s.error}'),
          ),
        );
      }
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: s.data!.length + 1,
        itemBuilder: (context, i) {
          if (i == 0) {
            return const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text(
                'Offline reading view · Text content. For original layout, use Original preview or a PDF copy.',
              ),
            );
          }
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Page $i',
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  const SizedBox(height: 14),
                  SelectableText(
                    s.data![i - 1].isEmpty
                        ? 'Graphics-only page. Use original preview or a PDF copy.'
                        : s.data![i - 1],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
