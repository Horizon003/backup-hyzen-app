import 'package:flutter/material.dart';

import '../academics/domain/drive.dart';
import 'preview_frame.dart';

/// Opens Drive's online viewer immediately. The old implementation downloaded
/// the complete document to a temporary file before showing page 1, which made
/// large notes appear frozen. Offline copies are now fetched only when the
/// learner explicitly taps Save offline in the viewer bar.
class NativePreview extends StatelessWidget {
  const NativePreview({
    super.key,
    required this.url,
  });

  final String url;

  @override
  Widget build(BuildContext context) => PreviewFrame(
    key: ValueKey(url),
    url: DriveLinks.previewUrl(url),
  );
}
