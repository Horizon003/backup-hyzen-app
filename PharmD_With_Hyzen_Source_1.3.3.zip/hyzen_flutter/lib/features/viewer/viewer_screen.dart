import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/errors/app_error.dart';
import '../../core/theme/tokens.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/surfaces.dart';
import '../academics/domain/drive.dart';
import '../downloads/data/downloads_controller.dart';
import '../downloads/domain/download_record.dart';
import '../home/data/recent_controller.dart';
import 'offline_pdf.dart';
import 'native_preview.dart';
import '../../core/utils/links.dart';
import '../../core/utils/media_upload.dart';
import 'preview_frame.dart';

/// Document viewer. Native chrome, Back top-left, NO "Open original".
class ViewerScreen extends ConsumerStatefulWidget {
  const ViewerScreen({super.key, required this.file});
  final FileRef? file;
  @override
  ConsumerState<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends ConsumerState<ViewerScreen> {
  bool _preferOnline = false;

  @override
  void initState() {
    super.initState();
    final f = widget.file;
    if (f != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ref.read(recentProvider.notifier).touch(f);
      });
    }
  }

  Future<void> _save(FileRef f) async {
    try {
      await ref
          .read(downloadsProvider.notifier)
          .save(f);
      if (mounted) {
        showHSnack(context, 'Saved offline \u2014 find it in Downloads');
      }
    } on FriendlyException catch (e) {
      if (mounted) showHSnack(context, e.message, error: true);
    } catch (_) {
      if (mounted) {
        showHSnack(
          context,
          'Could not save this file. Please retry.',
          error: true,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.file;
    if (f == null) {
      return Scaffold(
        appBar: const HTopBar(title: 'Document'),
        body: EmptyState(
          icon: Icons.description_outlined,
          title: 'Nothing to show',
          action: HButton(
            label: 'Go home',
            onPressed: () => context.go('/home'),
          ),
        ),
      );
    }
    final rec = ref.watch(downloadForUrlProvider(f.url));
    final ready = rec?.isReady == true && !kIsWeb;
    final showOffline = ready && !_preferOnline;
    final t = Theme.of(context);
    return Scaffold(
      appBar: HTopBar(
        title: f.title,
        subtitle: f.trail.isEmpty ? null : f.trail.take(3).join(' \u203a '),
        actions: [
          IconButton(
            tooltip: 'Open in browser',
            icon: const Icon(Icons.open_in_new_rounded),
            onPressed: () => openLink(context, f.url),
          ),
          if (ready)
            IconButton(
              tooltip: 'Export saved file to device',
              icon: const Icon(Icons.save_alt_rounded),
              onPressed: () async {
                try {
                  final path = rec!.localPath!;
                  final ext = path.split('.').last;
                  final exportExt = ext == 'office' || ext == 'legacy'
                      ? (f.title.contains('.')
                            ? f.title.split('.').last
                            : 'bin')
                      : ext;
                  await MediaUpload.exportDocument(
                    path,
                    '${f.title.replaceFirst(RegExp(r"\.[^.]+$"), "").replaceAll(RegExp(r"[^a-zA-Z0-9 _-]"), "")}.$exportExt',
                    ext == 'pdf'
                        ? 'application/pdf'
                        : {
                                'jpg': 'image/jpeg',
                                'png': 'image/png',
                                'webp': 'image/webp',
                              }[ext] ??
                              'application/octet-stream',
                  );
                } catch (_) {
                  if (context.mounted) {
                    showHSnack(context, 'Could not export PDF.', error: true);
                  }
                }
              },
            ),
          if (ready)
            IconButton(
              tooltip: showOffline
                  ? 'Show online preview'
                  : 'Open offline copy',
              icon: Icon(
                showOffline ? Icons.cloud_outlined : Icons.offline_pin_rounded,
              ),
              onPressed: () => setState(() => _preferOnline = !_preferOnline),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: showOffline
                ? OfflinePdf(path: rec!.localPath!)
                : !kIsWeb
                ? NativePreview(
                    key: ValueKey(f.url),
                    url: f.url,
                  )
                : PreviewFrame(
                    key: ValueKey(f.url),
                    url: DriveLinks.previewUrl(f.url),
                  ),
          ),
          if (!kIsWeb)
            SafeArea(
              top: false,
              child: SurfacePanel(
                radius: 0,
                padding: const EdgeInsets.fromLTRB(
                  HSpace.md,
                  HSpace.sm,
                  HSpace.md,
                  HSpace.sm,
                ),
                child: _OfflineBar(
                  rec: rec,
                  onSave: () => _save(f),
                  onOpen: () => setState(() => _preferOnline = false),
                  onCancel: () => ref
                      .read(downloadsProvider.notifier)
                      .cancel(DriveLinks.offlineKey(f.url)),
                  theme: t,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _OfflineBar extends StatelessWidget {
  const _OfflineBar({
    required this.rec,
    required this.onSave,
    required this.onOpen,
    required this.onCancel,
    required this.theme,
  });
  final DownloadRecord? rec;
  final VoidCallback onSave, onOpen, onCancel;
  final ThemeData theme;
  @override
  Widget build(BuildContext context) {
    final r = rec;
    if (r != null && r.status == DownloadStatus.downloading) {
      final p = r.progress;
      return Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  p > 0
                      ? 'Downloading ${(p * 100).round()}%'
                      : 'Downloading\u2026 ${formatBytes(r.sizeBytes)}',
                  style: theme.textTheme.titleSmall,
                ),
                Text(r.transferDetail, style: theme.textTheme.bodySmall),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: p > 0 ? p : null,
                    minHeight: 6,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: HSpace.sm),
          TextButton(onPressed: onCancel, child: const Text('Cancel')),
        ],
      );
    }
    if (r != null && r.isReady) {
      return Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const StatusPill(
            label: 'Saved offline',
            color: HColors.success,
            icon: Icons.download_done_rounded,
          ),
          const SizedBox(width: 8),
          Text(formatBytes(r.sizeBytes), style: theme.textTheme.bodySmall),
          FilledButton.icon(
            onPressed: onOpen,
            icon: const Icon(Icons.menu_book_rounded),
            label: const Text('Open offline'),
          ),
        ],
      );
    }
    if (r != null && r.status == DownloadStatus.failed) {
      return Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: HColors.error),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              r.error ?? 'Download failed',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall,
            ),
          ),
          const SizedBox(width: 8),
          FilledButton.icon(
            onPressed: onSave,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Retry'),
          ),
        ],
      );
    }
    return Row(
      children: [
        Icon(Icons.cloud_download_outlined, color: theme.colorScheme.primary),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            'Keep this note for offline reading',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodySmall,
          ),
        ),
        const SizedBox(width: 8),
        FilledButton.icon(
          onPressed: onSave,
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 48),
            padding: const EdgeInsets.symmetric(horizontal: 12),
          ),
          icon: const Icon(Icons.download_rounded, size: 18),
          label: const Text('Save'),
        ),
      ],
    );
  }
}
