import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../notifications/notifications_screen.dart';
import '../updates/update_ui.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/tokens.dart';
import '../../core/widgets/surfaces.dart';

/// Authenticated shell: Material navigation with Android back handling.
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.navigationShell});
  final StatefulNavigationShell navigationShell;

  static const _items = [
    (Icons.home_outlined, Icons.home_rounded, 'Home'),
    (Icons.school_outlined, Icons.school_rounded, 'Study'),
    (Icons.search_rounded, Icons.manage_search_rounded, 'Search'),
    (Icons.picture_as_pdf_outlined, Icons.picture_as_pdf_rounded, 'PDF Studio'),
    (Icons.download_outlined, Icons.download_done_rounded, 'Downloads'),
    (Icons.person_outline_rounded, Icons.person_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final idx = navigationShell.currentIndex;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (FocusManager.instance.primaryFocus?.hasFocus == true &&
            MediaQuery.viewInsetsOf(context).bottom > 0) {
          FocusManager.instance.primaryFocus?.unfocus();
          return;
        }
        final router = GoRouter.of(context);
        if (router.canPop()) {
          router.pop();
          return;
        }
        if (idx != 0) {
          navigationShell.goBranch(0);
          return;
        }
        final leave = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('Close PHARM D WITH HYZEN?'),
            content: const Text('Your study progress and downloads are saved.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(c, false),
                child: const Text('Keep studying'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('Close app'),
              ),
            ],
          ),
        );
        if (leave == true) await SystemNavigator.pop();
      },
      child: Scaffold(
        body: UpdateGate(child: navigationShell),
        bottomNavigationBar: NavigationBar(
          height: 76,
          selectedIndex: idx,
          onDestinationSelected: (i) =>
              navigationShell.goBranch(i, initialLocation: i == idx),
          backgroundColor: t.colorScheme.surface,
          surfaceTintColor: Colors.transparent,
          indicatorColor: t.brightness == Brightness.light
              ? HColors.primarySoft
              : HColors.darkSurfaceAlt,
          destinations: [
            for (var i = 0; i < _items.length; i++)
              if (i == 3)
                NavigationDestination(
                  icon: _StudioDock(
                    icon: _items[i].$1,
                    selected: idx == i,
                    color: t.colorScheme.primary,
                  ),
                  selectedIcon: _StudioDock(
                    icon: _items[i].$2,
                    selected: true,
                    color: t.colorScheme.primary,
                  ),
                  label: _items[i].$3,
                )
              else
              NavigationDestination(
                icon: Icon(_items[i].$1),
                selectedIcon: Icon(_items[i].$2),
                label: _items[i].$3,
              ),
          ],
        ),
      ),
    );
  }
}

class _StudioDock extends StatelessWidget {
  const _StudioDock({
    required this.icon,
    required this.selected,
    required this.color,
  });
  final IconData icon;
  final bool selected;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
    width: selected ? 46 : 40,
    height: selected ? 46 : 40,
    decoration: BoxDecoration(
      color: color,
      shape: BoxShape.circle,
      boxShadow: [
        BoxShadow(
          color: color.withValues(alpha: .24),
          blurRadius: selected ? 12 : 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Icon(icon, color: Colors.white, size: 23),
  );
}

/// Standard tab page: persistent opaque top bar + background + bottom padding for nav.
class TabPage extends StatelessWidget {
  const TabPage({
    super.key,
    required this.title,
    required this.slivers,
    this.actions = const [],
    this.onRefresh,
    this.subtitle,
    this.drawer,
  });
  final Widget? drawer;
  final String title;
  final String? subtitle;
  final List<Widget> slivers;
  final List<Widget> actions;
  final Future<void> Function()? onRefresh;
  @override
  Widget build(BuildContext context) {
    final scroll = CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: SizedBox(
            height: MediaQuery.paddingOf(context).top + 80 + HSpace.sm,
          ),
        ),
        ...slivers,
        const SliverToBoxAdapter(child: SizedBox(height: 32)),
      ],
    );
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: drawer,
      appBar: _Bar(
        title: title,
        subtitle: subtitle,
        actions: actions,
        showMenu: drawer != null,
      ),
      body: HBackground(
        child: onRefresh == null
            ? scroll
            : RefreshIndicator(
                onRefresh: onRefresh!,
                edgeOffset: 80,
                child: scroll,
              ),
      ),
    );
  }
}

class _Bar extends StatelessWidget implements PreferredSizeWidget {
  const _Bar({
    required this.title,
    this.subtitle,
    this.actions = const [],
    this.showMenu = false,
  });
  final bool showMenu;
  final String title;
  final String? subtitle;
  final List<Widget> actions;
  @override
  Size get preferredSize => const Size.fromHeight(80);
  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return SurfacePanel(
      radius: 0,
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: 80,
          child: Row(
            children: [
              if (showMenu)
                IconButton(
                  tooltip: 'Admin menu',
                  icon: const Icon(Icons.menu_rounded),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                )
              // The root Home page can appear poppable when another tab has a
              // nested route in its retained navigator. Never show a dead
              // back arrow on the Home header.
              else if (title != 'PHARM D' && Navigator.of(context).canPop())
                IconButton(
                  tooltip: 'Back',
                  icon: const Icon(Icons.arrow_back_rounded),
                  onPressed: () => context.pop(),
                )
              else
                const SizedBox(width: HSpace.screen),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: t.textTheme.headlineMedium?.copyWith(
                        color: title == 'PHARM D' ? t.colorScheme.primary : null,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    if (subtitle != null)
                      Text(
                        subtitle!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: t.textTheme.bodyMedium,
                      ),
                  ],
                ),
              ),
              ...actions,
              const NotificationBell(),
              const SizedBox(width: 6),
            ],
          ),
        ),
      ),
    );
  }
}

/// Small "offline copy" hint shown when content came from cache.
class OfflineHint extends StatelessWidget {
  const OfflineHint({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(
      HSpace.screen,
      0,
      HSpace.screen,
      HSpace.sm,
    ),
    child: Row(
      children: [
        Icon(
          Icons.cloud_off_rounded,
          size: 16,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 6),
        Text(
          'Showing saved copy \u00b7 pull to refresh',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    ),
  );
}
