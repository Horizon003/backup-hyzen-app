import 'package:flutter/material.dart';

import '../../../core/utils/media_upload.dart';
import '../../../core/widgets/common.dart';
import '../data/studio_file_item.dart';
import '../data/studio_pdf_engine.dart';
import '../data/studio_text_export.dart';

enum _ExportFormat { original, annotated, text, docx, png, jpg }
enum _Destination { device, share }

Future<void> showStudioExportSheet(BuildContext context, StudioFileItem file) async {
  final pdf = file.internalFilePath.toLowerCase().endsWith('.pdf');
  final notes = pdf
      ? await StudioPdfEngine.readAnnotations(file.editStateJsonPath)
      : <String, List<Map<String, dynamic>>>{};
  if (!context.mounted) return;
  final hasMarks = notes.values.any((page) => page.isNotEmpty);
  final format = await showModalBottomSheet<_ExportFormat>(
    context: context,
    showDragHandle: true,
    builder: (sheet) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const ListTile(title: Text('Export document'), subtitle: Text('Choose the format for your copy')),
      ListTile(leading: const Icon(Icons.file_present), title: Text(pdf ? 'Original PDF' : 'Original file'),
        onTap: () => Navigator.pop(sheet, _ExportFormat.original)),
      if (pdf) ...[
        if (hasMarks)
          ListTile(leading: const Icon(Icons.draw_rounded), title: const Text('Flatten annotated PDF'),
            subtitle: const Text('Visual copy; original remains editable here'),
            onTap: () => Navigator.pop(sheet, _ExportFormat.annotated)),
        ListTile(leading: const Icon(Icons.text_snippet_outlined), title: const Text('Extract text · TXT'),
          subtitle: const Text('Scanned image pages need OCR'), onTap: () => Navigator.pop(sheet, _ExportFormat.text)),
        ListTile(leading: const Icon(Icons.description_outlined), title: const Text('Extract text · DOCX'),
          subtitle: const Text('Plain paragraphs; original PDF layout is not retained'),
          onTap: () => Navigator.pop(sheet, _ExportFormat.docx)),
        ListTile(leading: const Icon(Icons.image_outlined), title: const Text('PNG pages · ZIP'),
          onTap: () => Navigator.pop(sheet, _ExportFormat.png)),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('JPG pages · ZIP'),
          onTap: () => Navigator.pop(sheet, _ExportFormat.jpg)),
      ],
    ])),
  );
  if (format == null || !context.mounted) return;
  final destination = await showModalBottomSheet<_Destination>(
    context: context,
    showDragHandle: true,
    builder: (sheet) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const ListTile(title: Text('Where should this copy go?')),
      ListTile(leading: const Icon(Icons.save_alt), title: const Text('Save As on device'),
        onTap: () => Navigator.pop(sheet, _Destination.device)),
      ListTile(leading: const Icon(Icons.share), title: const Text('Share with an app'),
        onTap: () => Navigator.pop(sheet, _Destination.share)),
    ])),
  );
  if (destination == null || !context.mounted) return;
  try {
    var path = file.internalFilePath;
    var name = file.displayName;
    var mime = pdf ? 'application/pdf' : 'application/octet-stream';
    if (format == _ExportFormat.text || format == _ExportFormat.docx) {
      final text = await extractStudioPdfText(path);
      if (text.trim().isEmpty) throw const FormatException('This PDF has no selectable text.');
      final stem = name.replaceFirst(RegExp(r'\.pdf$', caseSensitive: false), '');
      name = '$stem.${format == _ExportFormat.docx ? 'docx' : 'txt'}';
      if (format == _ExportFormat.text && destination == _Destination.device) {
        final saved = await MediaUpload.exportText(name, text);
        if (context.mounted) showHSnack(context, saved ? 'Text saved' : 'Export cancelled');
        return;
      }
      path = format == _ExportFormat.docx
          ? await StudioPdfEngine.textToDocx(text)
          : await StudioPdfEngine.textFile(text);
      mime = format == _ExportFormat.docx
          ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
          : 'text/plain';
    } else if (format == _ExportFormat.annotated) {
      final count = await StudioPdfEngine.pageCount(path);
      path = await StudioPdfEngine.compose([
        for (var index = 0; index < count; index++)
          StudioPage(file.internalFilePath, index,
            annotations: notes['${index + 1}'] ?? const []),
      ]);
      name = '${name.replaceFirst(RegExp(r'\.pdf$', caseSensitive: false), '')}_annotated.pdf';
    } else if (format == _ExportFormat.png || format == _ExportFormat.jpg) {
      path = await StudioPdfEngine.pagesToImages(path, format == _ExportFormat.png ? 'png' : 'jpg');
      name = '${name.replaceFirst(RegExp(r'\.pdf$', caseSensitive: false), '')}_pages.zip';
      mime = 'application/zip';
    }
    final ok = destination == _Destination.device
        ? await MediaUpload.exportDocument(path, name, mime)
        : await MediaUpload.shareDocument(path, name, mime);
    if (context.mounted) showHSnack(context, ok ? 'Ready' : 'Export cancelled');
  } catch (error) {
    if (context.mounted) showHSnack(context, 'Export failed: $error', error: true);
  }
}
