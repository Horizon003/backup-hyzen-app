import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/tokens.dart';
import '../../../core/utils/media_upload.dart';
import '../../../core/widgets/common.dart';
import '../../../core/widgets/surfaces.dart';
import '../../../core/widgets/ui_kit.dart';
import '../../downloads/domain/download_record.dart';
import '../../shell/app_shell.dart';
import '../../viewer/external_files.dart';
import '../../viewer/offline_pdf.dart';
import '../data/pdf_studio_repository.dart';
import '../data/studio_file_item.dart';
import 'studio_tools_screen.dart';
import 'studio_export_sheet.dart';
import 'studio_annotation_screen.dart';

enum _StudioFilter { all, edited, mergedSplit, docs, external }

String _studioMime(String path) => switch (path.split('.').last.toLowerCase()) {
  'pdf' => 'application/pdf',
  'doc' => 'application/msword',
  'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'ppt' => 'application/vnd.ms-powerpoint',
  'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'xls' => 'application/vnd.ms-excel',
  'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'txt' => 'text/plain',
  'md' => 'text/markdown',
  'jpg' || 'jpeg' => 'image/jpeg',
  'png' => 'image/png',
  'webp' => 'image/webp',
  _ => 'application/octet-stream',
};

class PdfStudioScreen extends ConsumerStatefulWidget {
  const PdfStudioScreen({super.key});

  @override
  ConsumerState<PdfStudioScreen> createState() => _PdfStudioScreenState();
}

class _PdfStudioScreenState extends ConsumerState<PdfStudioScreen> {
  _StudioFilter _filter = _StudioFilter.all;
  String _query = '';

  bool _matches(StudioFileItem file) {
    final filterMatch = switch (_filter) {
      _StudioFilter.all => true,
      _StudioFilter.edited => file.operationBadge == 'EDITED',
      _StudioFilter.mergedSplit =>
        file.operationBadge == 'MERGED' || file.operationBadge == 'SPLIT',
      _StudioFilter.docs => file.fileCategory == 'DOC',
      _StudioFilter.external => file.sourceType == 'EXTERNAL_INTENT',
    };
    return filterMatch &&
        (_query.isEmpty ||
            '${file.displayName} ${file.originalFileName}'
                .toLowerCase()
                .contains(_query.toLowerCase()));
  }

  @override
  Widget build(BuildContext context) {
    final history = ref.watch(pdfStudioHistoryProvider).where(_matches).toList();
    final external = ref.watch(externalHistoryProvider);
    final knownPaths = ref
        .watch(pdfStudioHistoryProvider)
        .map((item) => item.internalFilePath)
        .toSet();
    final notImported = _filter == _StudioFilter.all ||
        _filter == _StudioFilter.external
        ? external.where((item) => !knownPaths.contains(item.path)).toList()
        : const <ExternalDocument>[];
    final theme = Theme.of(context);

    return TabPage(
      title: 'PDF Studio',
      subtitle: 'Your documents, together',
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: HSpace.screen),
          sliver: SliverList.list(
            children: [
              SurfacePanel(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.picture_as_pdf_rounded,
                      size: 34,
                      color: theme.colorScheme.primary,
                    ),
                    const Gap(12),
                    Text('Your private document workspace',
                        style: theme.textTheme.titleLarge),
                    const Gap(6),
                    Text(
                      'Bring a PDF or document into Studio to keep a private copy, return to it later, and track your reading history.',
                      style: theme.textTheme.bodyMedium,
                    ),
                    const Gap(14),
                    OutlinedButton.icon(
                      onPressed: () => context.go('/downloads'),
                      icon: const Icon(Icons.folder_open_rounded),
                      label: const Text('Browse imported files'),
                    ),
                  ],
                ),
              ),
              const Gap(HSpace.md),
              Text('Create & edit', style: theme.textTheme.titleLarge),
              const Gap(HSpace.sm),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final action in <(StudioTool, IconData, String)>[
                  (StudioTool.open, Icons.folder_open_rounded, 'Open file'),
                  (StudioTool.merge, Icons.merge_type_rounded, 'Merge PDFs'),
                  (StudioTool.split, Icons.call_split_rounded, 'Split PDF'),
                  (StudioTool.organize, Icons.auto_awesome_motion_rounded, 'Organize pages'),
                  (StudioTool.document, Icons.edit_document, 'Write document'),
                  (StudioTool.images, Icons.image_rounded, 'Images to PDF'),
                ])
                  ActionChip(
                    avatar: Icon(action.$2, size: 18, color: theme.colorScheme.primary),
                    label: Text(action.$3),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => StudioToolsScreen(tool: action.$1),
                    )),
                  ),
              ]),
              const Gap(HSpace.md),
              HSearchField(
                hint: 'Search your Studio workspace',
                onChanged: (value) => setState(() => _query = value),
              ),
              const Gap(HSpace.sm),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final filter in _StudioFilter.values)
                      Padding(
                        padding: const EdgeInsets.only(right: 5),
                        child: ChoiceChip(
                          label: Text(switch (filter) {
                            _StudioFilter.all => 'All recent',
                            _StudioFilter.edited => 'Edited',
                            _StudioFilter.mergedSplit => 'Merged & split',
                            _StudioFilter.docs => 'Docs',
                            _StudioFilter.external => 'External (saved)',
                          }),
                          selected: _filter == filter,
                          visualDensity: VisualDensity.compact,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                          onSelected: (_) => setState(() => _filter = filter),
                        ),
                      ),
                  ],
                ),
              ),
              const Gap(HSpace.sm),
              Row(
                children: [
                  Expanded(
                    child: Text('Workspace history',
                        style: theme.textTheme.titleLarge),
                  ),
                  Text('${history.length}', style: theme.textTheme.labelLarge),
                ],
              ),
              if (history.isEmpty && notImported.isEmpty)
                const EmptyState(
                  icon: Icons.description_outlined,
                  title: 'Your workspace is ready',
                  message:
                      'Open a PDF or document from another app with PHARM D WITH HYZEN, then save it here to keep a private workspace copy.',
                ),
              for (final file in history) _StudioHistoryTile(file: file),
              if (notImported.isNotEmpty) ...[
                const Gap(HSpace.md),
                Text('Opened with PHARM D WITH HYZEN', style: theme.textTheme.titleMedium),
                Text(
                  'Copy an imported file into the separate Studio workspace.',
                  style: theme.textTheme.bodySmall,
                ),
                const Gap(HSpace.xs),
                for (final file in notImported)
                  ResourceTile(
                    icon: Icons.file_present_rounded,
                    color: HColors.primary,
                    eyebrow: 'DEVICE IMPORT',
                    title: file.title,
                    subtitle:
                        'Opened ${file.openedAt.toLocal().toString().split('.').first}',
                    trailing: IconButton(
                      tooltip: 'Save to PDF Studio workspace',
                      icon: const Icon(Icons.save_alt_rounded),
                      onPressed: () async {
                        try {
                          final item = await ref
                              .read(pdfStudioHistoryProvider.notifier)
                              .importFile(
                                file.path,
                                originalFileName: file.title,
                                sourceType: 'EXTERNAL_INTENT',
                                operationBadge: 'IMPORTED',
                              );
                          if (context.mounted) {
                            showHSnack(context, 'Saved to PDF Studio');
                            context.push('/pdf-studio/viewer/${item.id}');
                          }
                        } catch (_) {
                          if (context.mounted) {
                            showHSnack(
                              context,
                              'Could not copy this file into Studio.',
                              error: true,
                            );
                          }
                        }
                      },
                    ),
                  ),
              ],
              const Gap(HSpace.md),
            ],
          ),
        ),
      ],
    );
  }
}

class _StudioHistoryTile extends ConsumerWidget {
  const _StudioHistoryTile({required this.file});
  final StudioFileItem file;

  @override
  Widget build(BuildContext context, WidgetRef ref) => ResourceTile(
    icon: file.fileCategory == 'PDF'
        ? Icons.picture_as_pdf_rounded
        : Icons.description_rounded,
    color: HColors.primary,
    eyebrow: '${file.operationBadge} · ${file.fileCategory}',
    title: file.displayName,
    subtitle:
        '${formatBytes(file.fileSizeBytes)} · ${file.pageCount > 0 ? '${file.pageCount} pages' : 'Page count not scanned'}',
    badge: file.isStarred
        ? const StatusPill(
            label: 'Starred',
            color: HColors.warning,
            icon: Icons.star_rounded,
          )
        : null,
    onTap: () => context.push('/pdf-studio/viewer/${file.id}'),
    trailing: PopupMenuButton<String>(
      tooltip: 'Document actions',
      onSelected: (action) async {
        if (action == 'star') {
          await ref
              .read(pdfStudioHistoryProvider.notifier)
              .setStarred(file.id, !file.isStarred);
        } else if (action == 'rename') {
          final controller = TextEditingController(text: file.displayName);
          final name = await showDialog<String>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Rename document'),
              content: TextField(
                controller: controller,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'Display name'),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, controller.text),
                  child: const Text('Save'),
                ),
              ],
            ),
          );
          controller.dispose();
          if (name != null) {
            await ref.read(pdfStudioHistoryProvider.notifier).rename(file.id, name);
          }
        } else if (action == 'export') {
          await showStudioExportSheet(context, file);
        } else if (action == 'delete') {
          final confirm = await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Delete workspace copy?'),
              content: Text('“${file.displayName}” will be deleted from Studio.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  child: const Text('Delete'),
                ),
              ],
            ),
          );
          if (confirm == true) {
            await ref.read(pdfStudioHistoryProvider.notifier).delete(file.id);
          }
        }
      },
      itemBuilder: (_) => [
        PopupMenuItem(
          value: 'star',
          child: Text(file.isStarred ? 'Remove star' : 'Star document'),
        ),
        const PopupMenuItem(value: 'rename', child: Text('Rename')),
        const PopupMenuItem(value: 'export', child: Text('Export to device')),
        const PopupMenuItem(value: 'delete', child: Text('Delete from Studio')),
      ],
    ),
  );
}

class PdfStudioFileViewerScreen extends ConsumerStatefulWidget {
  const PdfStudioFileViewerScreen({super.key, required this.fileId});
  final String fileId;

  @override
  ConsumerState<PdfStudioFileViewerScreen> createState() =>
      _PdfStudioFileViewerScreenState();
}

class _PdfStudioFileViewerScreenState
    extends ConsumerState<PdfStudioFileViewerScreen> {
  bool _recorded = false;

  @override
  Widget build(BuildContext context) {
    final files = ref.watch(pdfStudioHistoryProvider);
    StudioFileItem? found;
    for (final item in files) {
      if (item.id == widget.fileId) found = item;
    }
    if (found == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('PDF Studio')),
        body: const EmptyState(
          icon: Icons.error_outline_rounded,
          title: 'Document not found',
          message: 'It may have been deleted from the workspace.',
        ),
      );
    }
    final active = found;
    if (!_recorded) {
      _recorded = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          ref.read(pdfStudioHistoryProvider.notifier).recordOpen(active.id);
        }
      });
    }
    return Scaffold(
      appBar: HTopBar(
        title: active.displayName,
        actions: [
          if (active.fileCategory == 'PDF')
            IconButton(
              tooltip: 'Annotate this PDF',
              icon: const Icon(Icons.draw_rounded),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => StudioAnnotationScreen(file: active),
              )),
            ),
          if (active.fileCategory == 'PDF')
            PopupMenuButton<StudioTool>(
              tooltip: 'PDF tools',
              icon: const Icon(Icons.tune_rounded),
              onSelected: (tool) => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => StudioToolsScreen(tool: tool, initialFile: active),
              )),
              itemBuilder: (_) => const [
                PopupMenuItem(value: StudioTool.split, child: Text('Split / extract pages')),
                PopupMenuItem(value: StudioTool.organize, child: Text('Reorder / rotate pages')),
              ],
            ),
          if (active.internalFilePath.toLowerCase().endsWith('.txt'))
            IconButton(
              tooltip: 'Edit text copy',
              icon: const Icon(Icons.edit_note_rounded),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => StudioToolsScreen(tool: StudioTool.document, initialFile: active),
              )),
            ),
          IconButton(
            tooltip: active.isStarred ? 'Remove star' : 'Star',
            onPressed: () => ref
                .read(pdfStudioHistoryProvider.notifier)
                .setStarred(active.id, !active.isStarred),
            icon: Icon(active.isStarred ? Icons.star : Icons.star_outline),
          ),
          IconButton(
            tooltip: 'Share original file',
            onPressed: () async {
              try {
                final ok = await MediaUpload.shareDocument(
                  active.internalFilePath,
                  active.displayName,
                  _studioMime(active.internalFilePath),
                );
                if (context.mounted && !ok) {
                  showHSnack(context, 'Share was cancelled.');
                }
              } catch (_) {
                if (context.mounted) {
                  showHSnack(context, 'Could not share this file.', error: true);
                }
              }
            },
            icon: const Icon(Icons.share_rounded),
          ),
          IconButton(
            tooltip: 'Save a copy to device',
            onPressed: () => showStudioExportSheet(context, active),
            icon: const Icon(Icons.save_alt_rounded),
          ),
        ],
      ),
      body: OfflinePdf(path: active.internalFilePath),
    );
  }
}
