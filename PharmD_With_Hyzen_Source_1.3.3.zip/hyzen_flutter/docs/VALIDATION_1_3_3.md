# Validation boundary — source 1.3.3+7

## Performed in this workspace

- Parsed Android manifest, native launcher drawable and both brand SVG files as XML.
- Rendered and visually inspected the new HD capsule app icon; generated Android launcher sizes and web icons from the same source.
- Checked source delimiters for the modified Dart and Kotlin modules; this is a structural check, not compilation.
- Verified ZIP integrity and exclusion of the production keystore and `android/key.properties`.
- Verified the original private production signing files still exist in the active project workspace.

## Could not run here

- `flutter --version`: command not found. Flutter SDK and Dart analyzer are unavailable.
- `./gradlew assembleRelease --offline`: Gradle wrapper attempted to download Gradle 8.13 and failed with `java.net.SocketException: Network is unreachable`.
- `flutter analyze`, `flutter test`, Android build and device installation are therefore pending. The older 1.3.0 APK is not this source.

## Device acceptance before release

Build version 1.3.3+7 with the original owner keystore. Verify upgrading over the installed signed app, external PDF opening, online preview, offline save/reopen, PDF Studio import, every manipulation/export action with real files, annotations after relaunch, share, dark theme, and Android Back navigation. Inspect the rasterized output quality and file size for large PDFs.
